OneOf Button Test - Michael Maher:

Button.sol is solidity file for Button project.

I used Hardhat with Typescript and I used the Hardhat network for testing.

Build, compile, ,test can all be done with yarn hardhat or npm hardhat.

Thank you for the opportunity!!
